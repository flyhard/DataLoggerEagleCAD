EAGLE Libraries
===============

	SparkFun.lbr: SparkFun's library
	at91sam9261.lbr: Atmel AT91 ARM9 library
	avr-6.lbr: Atmel library
	brokenlcd.lbr: My custom library
	philips_lpc12xx.lbr: NXP/Philips LPC21xx ARM7TDMI library

Other
=====
	sfe-gerb274x.cam: Gerber processing job for batchPCB
	SparkFun.dru: SparkFun / batchPCB design rule check

